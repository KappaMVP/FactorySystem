import pymysql
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow,QAbstractItemView
from PyQt5 import QtCore,  QtWidgets
 


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(QtCore.QRect(260, 240, 271, 221))
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setRowCount(6)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        
        
        self.select = QtWidgets.QPushButton(self.centralwidget)
        self.select.setGeometry(QtCore.QRect(330, 470, 93, 28))
        self.select.setObjectName("select")

        self.delete = QtWidgets.QPushButton(self.centralwidget)
        self.delete.setGeometry(QtCore.QRect(33, 470, 50, 56))
        self.delete.setObjectName("delete")

        self.add = QtWidgets.QPushButton(self.centralwidget)
        self.add.setGeometry(QtCore.QRect(150, 270, 50, 56))
        self.add.setObjectName("add")
        
        self.account = QtWidgets.QLineEdit(self.centralwidget)
        self.account.setGeometry(QtCore.QRect(280, 110, 113, 22))
        self.account.setObjectName("account")
        self.password = QtWidgets.QLineEdit(self.centralwidget)
        self.password.setGeometry(QtCore.QRect(280, 160, 113, 22))
        self.password.setObjectName("password")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(190, 110, 58, 15))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(190, 160, 58, 15))
        self.label_2.setObjectName("label_2")
        self.login = QtWidgets.QPushButton(self.centralwidget)
        self.login.setGeometry(QtCore.QRect(460, 140, 93, 28))
        self.login.setObjectName("login")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 25))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)#设置表格的选取方式是行选取
        self.tableWidget.setSelectionMode(QAbstractItemView.SingleSelection)#设置选取方式为单个选取

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        item = self.tableWidget.verticalHeaderItem(0)
        item.setText(_translate("MainWindow", "1"))
        item = self.tableWidget.verticalHeaderItem(1)
        item.setText(_translate("MainWindow", "2"))
        item = self.tableWidget.verticalHeaderItem(2)
        item.setText(_translate("MainWindow", "3"))
        item = self.tableWidget.verticalHeaderItem(3)
        item.setText(_translate("MainWindow", "4"))
        item = self.tableWidget.verticalHeaderItem(4)
        item.setText(_translate("MainWindow", "5"))
        item = self.tableWidget.verticalHeaderItem(5)
        item.setText(_translate("MainWindow", "6"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "ID"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "姓名"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", " "))
        
        self.label.setText(_translate("MainWindow", "帳號"))
        self.label_2.setText(_translate("MainWindow", "密碼"))
        #新刪修查
        self.select.setText(_translate("MainWindow", "讀取"))
        self.login.setText(_translate("MainWindow", "登入"))
        self.delete.setText(_translate("MainWindow", "刪除"))
        self.add.setText(_translate("MainWindow", "新增"))
        

catch_conn=[]#接收db

class OpenForm(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(OpenForm, self).__init__(parent)
        self.setupUi(self)
        self.login.clicked.connect(self.Login)
        self.select.clicked.connect(self.Select)        
        self.delete.clicked.connect(self.Delete) 
        self.tableWidget.itemChanged.connect(self.UpDate)
        self.add.clicked.connect(self.Add)
        
        
        
        
    # 【登入】按钮功能
    def Login(self):
        # 數據庫連接
        
        conn = pymysql.connect(host='localhost', port=3306, user=self.account.text(), password=self.password.text(), db="test")
        catch_conn.append(conn)
       
        
        
        # 讀取功能
    def Select(self):
        cur = catch_conn[0].cursor()
        
        # 查询的sql语句
        sql = "SELECT * FROM tab"
        cur.execute(sql)
        # 获取查询到的数据, 是以二维元组的形式存储的, 所以读取需要使用 data[i][j] 下标定位
        data = cur.fetchall()
        # 打印测试
        print(data)
        # print(data[0][1]) # 打印第1行第2个数据, 也就是小明

        # 遍历二维元组, 将 id 和 name 显示到界面表格上
        
        x = 0
        for i in data:
            y = 0
            for j in i:
                self.tableWidget.setItem(x, y, QtWidgets.QTableWidgetItem(str(data[x][y])))
                y +=  1
            x += 1



    def Delete(self):
        #是否刪除的對話方塊
        cur = catch_conn[0].cursor()
            #當前行
        row_2 = self.tableWidget.currentRow()
        del_d = self.tableWidget.item(row_2, 0).text()

            #在資料庫刪除資料
        cur.execute("DELETE FROM tab WHERE id = '"+del_d+"'")
        catch_conn[0].commit()
        self.tableWidget.removeRow(row_2)


    def UpDate(self):
        
        
        row_select = self.tableWidget.selectedItems()
        
        
        if len(row_select) == 0:
            return
        update_id = row_select[0].text()
        new_name = row_select[1].text()
        
        
        
        catch_conn[0].cursor().execute("UPDATE tab SET name ='"+new_name+"' WHERE id = '"+update_id+"'" )
        catch_conn[0].commit()
       

    def Add(self):
        row = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row)
        
        db_id,db_action=QtWidgets.QInputDialog.getText(self,'','請輸入ID',QtWidgets.QLineEdit.Normal)
        db_name,db_action = QtWidgets.QInputDialog.getText(self,'','請輸入名稱',QtWidgets.QLineEdit.Normal)
        


        catch_conn[0].cursor().execute("INSERT INTO `tab` (`id`, `name`) VALUES ('"+str(db_id)+"', '"+str(db_name)+"')" )
        catch_conn[0].commit()
        
            

'''
    def Add(self):
        
        
        try:
            # 调用输入框获取数据库名称
            db_text,db_action = QtWidgets.QInputDialog.getText(self,'数','请输入数据库名称',QtWidgets.QLineEdit.Normal)

            if (db_text.replace(' ','') != '') and (db_action is True):
                print(db_text)
                self.db_name = db_text
               
                print('创建数据库成功')
        except Exception as e:
            print(e)
'''       
        
      
        



    
    
    

        
if __name__ == "__main__":
    #固定的，PyQt5程序都需要QApplication对象。sys.argv是命令行参数列表，确保程序可以双击运行
    app = QApplication(sys.argv)
    #初始化
    myWin = OpenForm()
    #将窗口控件显示在屏幕上
    myWin.show()
    #程序运行，sys.exit方法确保程序完整退出。
    sys.exit(app.exec_())

'''
INSERT INTO `tab` (`id`, `name`) VALUES ('1', '小明'), ('2', '小紅');
'''
